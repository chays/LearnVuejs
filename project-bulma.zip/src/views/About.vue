<template>
  <div class="about">
    <h1 class="title">About</h1>
    
  </div>
</template>
