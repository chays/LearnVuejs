<template>
  <div class="blog">
    <h1 class="title">Blog</h1>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
