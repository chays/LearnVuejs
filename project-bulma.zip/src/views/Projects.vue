<template>
  <div class="projects">
    <h1 class="title">Project</h1>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
