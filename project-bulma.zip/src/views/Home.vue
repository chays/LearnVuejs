<template>
  <div class="home">
    <div class="column is-half is-home-left-column">left</div>
    <div class="column has-background-blue is-home-right-column">right</div>
  </div>
</template>

<script>
// @ is an alias to /src


export default {
  name: 'home'
}
</script>
