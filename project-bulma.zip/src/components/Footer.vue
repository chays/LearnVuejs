<template>
  <footer class="site-footer footer">
    <div class="columns">
      <div class="column is-one-fifth">
          <div class="columns">
              <div class="contact column">
                  <p><strong>Contact</strong></p>
                  <p><a href="tel:+33603351963">06&nbsp;03&nbsp;35&nbsp;19&nbsp;63</a></p>
              </div>

              <div class="siret column">
                  <p><strong>SIRET</strong></p>
                  <p>75068729500014</p>
              </div>
          </div>
      </div>
      <div class="column column-right has-text-right is-hidden-mobile">
          <div class="content">              
              <a href="https://github.com/fbnlsr/primative.net"><i class="fab fa-github"></i></a>
              <a href="https://twitter.com/fbnlsr" rel="me"><i class="fab fa-twitter"></i></a>
              <a href="/blog/index.xml"><i class="fas fa-rss"></i></a>
          </div>
      </div>  
    </div>
  </footer>
</template>

<script>
export default {

}
</script>

<style>

</style>
